مشروع لعبة وراء الحكاية - نسخة Android أولية

طريقة تحويله إلى APK:
1) حمّلي وثبّتي Android Studio على كمبيوتر Windows أو Mac.
2) فكّي ضغط الملف ZIP.
3) افتحي Android Studio ثم اختاري Open وافتحي مجلد WaraaAlhikaya.
4) انتظري Gradle Sync حتى يكمل، واقبلي تثبيت Android SDK إذا طلب ذلك.
5) من القائمة Build اختاري Build Bundle(s) / APK(s) ثم Build APK(s).
6) بعد نجاح البناء اضغطي locate في إشعار Android Studio. ستجدين الملف غالباً في:
   app/build/outputs/apk/debug/app-debug.apk
7) انقلي APK إلى الهاتف وافتحيه. إذا طلب الهاتف السماح بالتثبيت من هذا المصدر، فعّلي السماح لهذا التطبيق ثم ثبّتيه.

ملاحظات:
- هذه نسخة تجريبية أولى للعبة القصص، وليست لعبة منشورة على Google Play.
- تحتاج Android Studio وكمبيوتر لبناء APK بهذه الطريقة.
- لا تحتاج اللعبة إلى إنترنت بعد تثبيتها.
